﻿using Microsoft.EntityFrameworkCore;
using VetClinicSystem_Assign1.Models;

namespace VetClinicSystem_Assign1.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<VetDoctor> VetDoctors { get; set; }
        public DbSet<Pet> Pets { get; set; }
        public DbSet<PetProfile> PetProfiles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure one-to-many relationship: VetDoctor -> Pets
            modelBuilder.Entity<Pet>()
                .HasOne(p => p.VetDoctor)
                .WithMany(v => v.Pets)
                .HasForeignKey(p => p.VetDoctorId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure one-to-one relationship: Pet -> PetProfile
            modelBuilder.Entity<PetProfile>()
                .HasOne(pp => pp.Pet)
                .WithOne(p => p.PetProfile)
                .HasForeignKey<PetProfile>(pp => pp.PetId)
                .OnDelete(DeleteBehavior.Cascade);

            // Ensure MicrochipId is unique
            modelBuilder.Entity<Pet>()
                .HasIndex(p => p.MicrochipId)
                .IsUnique();
        }
    }
}
