﻿using VetClinicSystem_Assign1.Models;

namespace VetClinicSystem_Assign1.Data
{
    public static class DbInitializer
    {
        public static void Seed(AppDbContext context)
        {
            // Check if data already exists
            if (context.VetDoctors.Any())
            {
                return; // Database has been seeded
            }

            // Seed VetDoctors
            var doctors = new VetDoctor[]
            {
                new VetDoctor { Name = "Dr. Sarah Johnson", Specialty = "Small Animals" },
                new VetDoctor { Name = "Dr. Michael Chen", Specialty = "Emergency Medicine" },
                new VetDoctor { Name = "Dr. Emily Rodriguez", Specialty = "Exotic Animals" }
            };

            context.VetDoctors.AddRange(doctors);
            context.SaveChanges();

            // Seed Pets
            var pets = new Pet[]
            {
                new Pet { MicrochipId = "MIC001", Name = "Buddy", Species = "Dog", VetDoctorId = doctors[0].Id },
                new Pet { MicrochipId = "MIC002", Name = "Whiskers", Species = "Cat", VetDoctorId = doctors[0].Id },
                new Pet { MicrochipId = "MIC003", Name = "Charlie", Species = "Dog", VetDoctorId = doctors[1].Id },
                new Pet { MicrochipId = "MIC004", Name = "Luna", Species = "Rabbit", VetDoctorId = doctors[2].Id }
            };

            context.Pets.AddRange(pets);
            context.SaveChanges();

            // Seed PetProfiles with vet notes
            var profiles = new PetProfile[]
            {
                new PetProfile { PetId = pets[0].Id, VetNotes = "Regular checkup completed. Healthy weight maintained. Next visit scheduled in 6 months." },
                new PetProfile { PetId = pets[1].Id, VetNotes = "Annual vaccination updated. No health concerns noted. Owner advised on proper nutrition." },
                new PetProfile { PetId = pets[2].Id, VetNotes = "Emergency visit for minor injury. Wound cleaned and treated. Follow-up in 2 weeks." },
                new PetProfile { PetId = pets[3].Id, VetNotes = "Routine health examination. Excellent condition. Dietary recommendations provided for optimal health." }
            };

            context.PetProfiles.AddRange(profiles);
            context.SaveChanges();
        }
    }
}
