﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VetClinicSystem_Assign1.Models
{
    public class PetProfile
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [ForeignKey("Pet")]
        public int PetId { get; set; }

        [StringLength(5000)]
        public string VetNotes { get; set; } = string.Empty;

        // Navigation property
        public virtual Pet? Pet { get; set; }
    }
}
