﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VetClinicSystem_Assign1.Models
{
    public class Pet
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string MicrochipId { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        public string Species { get; set; } = string.Empty;

        [Required]
        [ForeignKey("VetDoctor")]
        public int VetDoctorId { get; set; }

        // Navigation properties
        public virtual VetDoctor? VetDoctor { get; set; }
        public virtual PetProfile? PetProfile { get; set; }
    }
}
