using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetClinicSystem_Assign1.Data;
using VetClinicSystem_Assign1.Models;

namespace VetClinicSystem_Assign1.Controllers
{
    [ApiController]
    [Route("api/vetdoctors")]
    public class VetDoctorController : ControllerBase
    {
        private readonly AppDbContext _context;

        public VetDoctorController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/vetdoctors
        [HttpGet]
        public async Task<ActionResult<IEnumerable<VetDoctor>>> GetAll()
        {
            var docs = await _context.VetDoctors
                .AsNoTracking()
                .ToListAsync();

            return Ok(docs);
        }

        // GET: api/vetdoctors/{id}
        // Must include pets
        [HttpGet("{id:int}")]
        public async Task<ActionResult<VetDoctor>> GetOne(int id)
        {
            var doc = await _context.VetDoctors
                .Include(v => v.Pets)
                .AsNoTracking()
                .FirstOrDefaultAsync(v => v.Id == id);

            if (doc == null)
                return NotFound($"VetDoctor with ID {id} not found.");

            return Ok(doc);
        }

        // POST: api/vetdoctors
        [HttpPost]
        public async Task<ActionResult<VetDoctor>> Create(VetDoctor vetDoctor)
        {
            _context.VetDoctors.Add(vetDoctor);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetOne), new { id = vetDoctor.Id }, vetDoctor);
        }

        // PUT: api/vetdoctors/{id}
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, VetDoctor vetDoctor)
        {
            if (id != vetDoctor.Id)
                return BadRequest("ID mismatch.");

            _context.Entry(vetDoctor).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VetDoctorExists(id))
                    return NotFound($"VetDoctor {id} not found.");

                throw;
            }

            return NoContent();
        }

        // DELETE: api/vetdoctors/{id}
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var vetDoctor = await _context.VetDoctors.FindAsync(id);

            if (vetDoctor == null)
                return NotFound($"VetDoctor {id} not found.");

            _context.VetDoctors.Remove(vetDoctor);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool VetDoctorExists(int id)
        {
            return _context.VetDoctors.Any(e => e.Id == id);
        }
    }
}
