using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using VetClinicSystem_Assign1.Data;
using VetClinicSystem_Assign1.Models;

namespace VetClinicSystem_Assign1.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;
        private readonly ILogger<HomeController> _logger;

        public HomeController(AppDbContext context, ILogger<HomeController> logger)
        {
            _context = context;
            _logger = logger;
        }

        public IActionResult Index()
        {
            ViewBag.DoctorCount = _context.VetDoctors.Count();
            ViewBag.PetCount = _context.Pets.Count();
            ViewBag.ProfileCount = _context.PetProfiles.Count();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

