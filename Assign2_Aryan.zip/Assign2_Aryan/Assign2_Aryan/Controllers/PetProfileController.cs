using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetClinicSystem_Assign1.Data;
using VetClinicSystem_Assign1.Models;

namespace VetClinicSystem_Assign1.Controllers
{
    [ApiController]
    [Route("api/petprofiles")]
    public class PetProfileController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PetProfileController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/petprofiles/{petId}
        [HttpGet("{petId:int}")]
        public async Task<ActionResult<PetProfile>> GetByPet(int petId)
        {
            var profile = await _context.PetProfiles
                .Include(p => p.Pet)
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.PetId == petId);

            if (profile == null)
                return NotFound($"Pet profile for PetId {petId} not found.");

            return Ok(profile);
        }

        // POST: api/petprofiles
        // Create OR Overwrite
        [HttpPost]
        public async Task<ActionResult<PetProfile>> CreateOrOverwrite([FromForm] int PetId, IFormFile? vetNotesFile)
        {
            // Validate pet exists
            if (!await _context.Pets.AnyAsync(p => p.Id == PetId))
                return BadRequest("PetId not found.");

            string? notes = null;

            // Read uploaded .txt file
            if (vetNotesFile != null && vetNotesFile.Length > 0)
            {
                if (Path.GetExtension(vetNotesFile.FileName).ToLower() != ".txt")
                    return BadRequest("Only .txt files are allowed.");

                using var reader = new StreamReader(vetNotesFile.OpenReadStream());
                notes = await reader.ReadToEndAsync();
            }

            // Check if profile already exists ? overwrite
            var existing = await _context.PetProfiles
                .FirstOrDefaultAsync(p => p.PetId == PetId);

            if (existing == null)
            {
                var newProfile = new PetProfile
                {
                    PetId = PetId,
                    VetNotes = notes ?? string.Empty
                };

                _context.PetProfiles.Add(newProfile);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetByPet), new { petId = PetId }, newProfile);
            }
            else
            {
                // Overwrite notes
                existing.VetNotes = notes ?? existing.VetNotes;
                _context.Entry(existing).State = EntityState.Modified;
                await _context.SaveChangesAsync();

                return Ok(existing);
            }
        }

        // PUT: api/petprofiles/{petId}
        // Updates notes ONLY (text)
        [HttpPut("{petId:int}")]
        public async Task<IActionResult> Update(int petId, [FromBody] string notes)
        {
            var profile = await _context.PetProfiles
                .FirstOrDefaultAsync(p => p.PetId == petId);

            if (profile == null)
                return NotFound($"Pet profile for PetId {petId} not found.");

            profile.VetNotes = notes ?? string.Empty;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/petprofiles/{petId}
        [HttpDelete("{petId:int}")]
        public async Task<IActionResult> Delete(int petId)
        {
            var profile = await _context.PetProfiles
                .FirstOrDefaultAsync(p => p.PetId == petId);

            if (profile == null)
                return NotFound($"Pet profile for PetId {petId} not found.");

            _context.PetProfiles.Remove(profile);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
