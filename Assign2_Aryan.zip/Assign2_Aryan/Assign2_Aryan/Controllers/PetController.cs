using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VetClinicSystem_Assign1.Data;
using VetClinicSystem_Assign1.Models;

namespace VetClinicSystem_Assign1.Controllers
{
    [ApiController]
    [Route("api/pets")]
    public class PetController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PetController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/pets
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Pet>>> GetAll()
        {
            var pets = await _context.Pets
                .Include(p => p.VetDoctor)
                .AsNoTracking()
                .ToListAsync();

            return Ok(pets);
        }

        // GET: api/pets/{id}
        // MUST include VetDoctor + PetProfile
        [HttpGet("{id:int}")]
        public async Task<ActionResult<Pet>> GetOne(int id)
        {
            var pet = await _context.Pets
                .Include(p => p.VetDoctor)
                .Include(p => p.PetProfile)
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.Id == id);

            if (pet == null)
                return NotFound($"Pet with ID {id} not found.");

            return Ok(pet);
        }

        // POST: api/pets
        [HttpPost]
        public async Task<ActionResult<Pet>> Create(Pet pet)
        {
            // Validate vet exists
            if (!await _context.VetDoctors.AnyAsync(v => v.Id == pet.VetDoctorId))
                return BadRequest("Invalid VetDoctorId.");

            _context.Pets.Add(pet);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetOne), new { id = pet.Id }, pet);
        }

        // PUT: api/pets/{id}
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, Pet pet)
        {
            if (id != pet.Id)
                return BadRequest("ID mismatch.");

            _context.Entry(pet).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PetExists(id))
                    return NotFound($"Pet with ID {id} not found.");

                throw;
            }

            return NoContent();
        }

        // DELETE: api/pets/{id}
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var pet = await _context.Pets.FindAsync(id);

            if (pet == null)
                return NotFound($"Pet with ID {id} not found.");

            _context.Pets.Remove(pet);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PetExists(int id)
        {
            return _context.Pets.Any(e => e.Id == id);
        }
    }
}
